function calculateAge() {
    const birthdate = new Date(document.getElementById("birthdate").value);
    const today = new Date();
    const age = today.getFullYear() - birthdate.getFullYear();

    const resultElement = document.getElementById("result");
    resultElement.innerHTML = `
        <span>Your age is:</span>
        <span class="age">${age}</span>
        <span class="years">years</span>
    `;

    resultElement.classList.add("result-animation");
    setTimeout(() => {
        resultElement.classList.remove("result-animation");
    }, 1000);
}